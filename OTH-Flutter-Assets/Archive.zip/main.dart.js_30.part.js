((a,b,c)=>{a[b]=a[b]||{}
a[b][c]=a[b][c]||[]
a[b][c].push({p:"main.dart.js_30",e:"beginPart"})})(self,"$__dart_deferred_initializers__","eventLog")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,A
B=c[36]
A=c[0]
var z=a.updateTypes([]);(function constants(){B.mh=new A.cY(57638,"MaterialIcons",null,!1)})()};
((a,b)=>{a[b]=a.current
a.eventLog.push({p:"main.dart.js_30",e:"endPart",h:b})})($__dart_deferred_initializers__,"GWsDFHf9QTsbbdU5A90ndXr0goI=");