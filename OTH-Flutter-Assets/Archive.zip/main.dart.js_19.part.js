((a,b,c)=>{a[b]=a[b]||{}
a[b][c]=a[b][c]||[]
a[b][c].push({p:"main.dart.js_19",e:"beginPart"})})(self,"$__dart_deferred_initializers__","eventLog")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B={
bfk(d){return new B.a_V(d,null)},
a_V:function a_V(d,e){this.c=d
this.a=e},
KJ:function KJ(d,e){this.c=d
this.a=e},
ava:function ava(d){this.a=d},
av6:function av6(d,e,f){this.a=d
this.b=e
this.c=f},
av5:function av5(d){this.a=d}},E,D,A,G,F,C
B=a.updateHolder(c[4],B)
E=c[31]
D=c[32]
A=c[0]
G=c[18]
F=c[17]
C=c[2]
B.a_V.prototype={
G(d){var x=null,w=this.c
if($.bF>768)return new E.jO(new B.KJ(w,x),x,x,x,!1,x)
else return D.qE(x,x,x,x,new B.KJ(w,x),-1,A.a_("categories"),x,!1)}}
B.KJ.prototype={
G(d){return D.eb(null,null,new B.ava(this),y.l,y.x)}}
var z=a.updateTypes(["ub(w,dM)"])
B.ava.prototype={
$2(d,e){var x,w=null,v={}
v.a=A.a([],y.v)
if(e instanceof A.iQ)v.a=e.c
x=this.a
return new D.ub(A.bI(A.a([new A.F(w,20,w,w),new G.L2(w),new A.F(w,20,w,w),new F.FP(x.c,!0,!1,w)],y.u),C.f,C.j,C.i,w),new B.av6(v,x,d),w)},
$S:z+0}
B.av6.prototype={
$0(){var x=0,w=A.P(y.e),v,u=this,t,s,r,q
var $async$$0=A.L(function(d,e){if(d===1)return A.M(e,w)
while(true)switch(x){case 0:r=u.a
q=C.b.iq(r.a,new B.av5(u.b))
if(q>-1){t=u.c
s=y.q
if(q===0){A.bD(t,!1).lF("categories",s,s)
v=!1
x=1
break}else{t=A.bD(t,!1)
r=r.a[q-1].a
r===$&&A.b()
t.lF("categories/"+r,s,s)
v=!1
x=1
break}}else{r=y.q
A.bD(u.c,!1).lF("home",r,r)
v=!1
x=1
break}case 1:return A.N(v,w)}})
return A.O($async$$0,w)},
$S:96}
B.av5.prototype={
$1(d){var x=d.a
x===$&&A.b()
return x===this.a.c},
$S:94};(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.ac,[B.a_V,B.KJ])
w(B.ava,A.f9)
w(B.av6,A.fx)
w(B.av5,A.f8)})()
A.eA(b.typeUniverse,JSON.parse('{"a_V":{"ac":[],"e":[]},"KJ":{"ac":[],"e":[]}}'))
var y={l:A.J("kb"),x:A.J("dM"),v:A.J("j<pD>"),u:A.J("j<e>"),e:A.J("y"),q:A.J("C?")}};
((a,b)=>{a[b]=a.current
a.eventLog.push({p:"main.dart.js_19",e:"endPart",h:b})})($__dart_deferred_initializers__,"DhCu9ithpgHrmrvipqBRJ6Bf+y0=");