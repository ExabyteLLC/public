((a,b,c)=>{a[b]=a[b]||{}
a[b][c]=a[b][c]||[]
a[b][c].push({p:"main.dart.js_20",e:"beginPart"})})(self,"$__dart_deferred_initializers__","eventLog")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B={aUG:function aUG(d,e){this.a=d
this.b=e},aUH:function aUH(d,e){this.a=d
this.b=e},WG:function WG(d,e,f){this.a=d
this.b=e
this.c=f},qY:function qY(d,e,f){var _=this
_.e=0
_.ds$=d
_.ap$=e
_.a=f},QL:function QL(d,e,f,g,h,i,j,k,l,m,n,o,p,q){var _=this
_.C=d
_.U=e
_.a7=f
_.T=g
_.V=h
_.M=i
_.O=j
_.av=k
_.bM=l
_.cL=!1
_.ca=m
_.er$=n
_.a9$=o
_.dM$=p
_.fy=_.fx=null
_.go=!1
_.k1=_.id=null
_.k2=0
_.a=!1
_.b=null
_.c=0
_.e=_.d=null
_.r=_.f=!1
_.w=null
_.x=!1
_.y=null
_.z=!0
_.Q=null
_.as=!1
_.at=null
_.ax=!1
_.ay=$
_.ch=q
_.CW=!1
_.cx=$
_.cy=!0
_.db=!1
_.dx=null
_.dy=!0
_.fr=null},anL:function anL(){},anM:function anM(){},
bkh(d){return new B.agY(d,null)},
agY:function agY(d,e){this.c=d
this.a=e},
L2:function L2(d){this.a=d},
awx:function awx(){},
awv:function awv(d){this.a=d},
aww:function aww(d,e){this.a=d
this.b=e}},C,A,D,G,E,F,J,H
B=a.updateHolder(c[18],B)
C=c[2]
A=c[0]
D=c[47]
G=c[32]
E=c[43]
F=c[45]
J=c[1]
H=c[35]
B.aUG.prototype={
J(){return"WrapAlignment."+this.b}}
B.aUH.prototype={
J(){return"WrapCrossAlignment."+this.b}}
B.WG.prototype={}
B.qY.prototype={}
B.QL.prototype={
sSp(d,e){if(this.C===e)return
this.C=e
this.ab()},
shJ(d){if(this.U===d)return
this.U=d
this.ab()},
saiA(d,e){if(this.a7===e)return
this.a7=e
this.ab()},
saSI(d){if(this.T===d)return
this.T=d
this.ab()},
saSJ(d){if(this.V===d)return
this.V=d
this.ab()},
sS_(d){if(this.M===d)return
this.M=d
this.ab()},
fB(d){if(!(d.b instanceof B.qY))d.b=new B.qY(null,null,C.k)},
bI(d){var x,w,v,u,t=this
switch(t.C.a){case 0:x=t.a9$
for(w=A.n(t).i("aD.1"),v=0;x!=null;){v=Math.max(v,x.aW(C.a5,1/0,x.gbR()))
u=x.b
u.toString
x=w.a(u).ap$}return v
case 1:return t.A1(new A.aL(0,1/0,0,d)).a}},
bu(d){var x,w,v,u,t=this
switch(t.C.a){case 0:x=t.a9$
for(w=A.n(t).i("aD.1"),v=0;x!=null;){v+=x.aW(C.ak,1/0,x.gc8())
u=x.b
u.toString
x=w.a(u).ap$}return v
case 1:return t.A1(new A.aL(0,1/0,0,d)).a}},
bB(d){var x,w,v,u,t=this
switch(t.C.a){case 0:return t.A1(new A.aL(0,d,0,1/0)).b
case 1:x=t.a9$
for(w=A.n(t).i("aD.1"),v=0;x!=null;){v=Math.max(v,x.aW(C.aL,1/0,x.gcn()))
u=x.b
u.toString
x=w.a(u).ap$}return v}},
bF(d){var x,w,v,u,t=this
switch(t.C.a){case 0:return t.A1(new A.aL(0,d,0,1/0)).b
case 1:x=t.a9$
for(w=A.n(t).i("aD.1"),v=0;x!=null;){v+=x.aW(C.bm,1/0,x.gcR())
u=x.b
u.toString
x=w.a(u).ap$}return v}},
hp(d){return this.S5(d)},
O9(d){switch(this.C.a){case 0:return d.a
case 1:return d.b}},
O8(d){switch(this.C.a){case 0:return d.b
case 1:return d.a}},
atT(d,e){switch(this.C.a){case 0:return new A.k(d,e)
case 1:return new A.k(e,d)}},
atz(d,e,f){var x=e-f
switch(this.M.a){case 0:return d?x:0
case 1:return d?0:x
case 2:return x/2}},
cC(d){return this.A1(d)},
A1(d){var x,w,v,u,t,s,r,q,p,o,n,m,l,k=this
switch(k.C.a){case 0:x=d.b
w=new A.aL(0,x,0,1/0)
break
case 1:x=d.d
w=new A.aL(0,1/0,0,x)
break
default:w=null
x=0}v=k.a9$
for(u=A.n(k).i("aD.1"),t=0,s=0,r=0,q=0,p=0;v!=null;){o=A.bfl(v,w)
n=k.O9(o)
m=k.O8(o)
if(p>0&&r+n+k.a7>x){t=Math.max(t,r)
s+=q+k.V
r=0
q=0
p=0}r+=n
q=Math.max(q,m)
if(p>0)r+=k.a7;++p
l=v.b
l.toString
v=u.a(l).ap$}s+=q
t=Math.max(t,r)
switch(k.C.a){case 0:return d.b7(new A.Z(t,s))
case 1:return d.b7(new A.Z(s,t))}},
bP(){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,b0,b1=this,b2="RenderBox was not laid out: ",b3=y.k.a(A.x.prototype.gad.call(b1))
b1.cL=!1
x=b1.a9$
if(x==null){b1.id=new A.Z(A.W(0,b3.a,b3.b),A.W(0,b3.c,b3.d))
return}switch(b1.C.a){case 0:w=b3.b
v=new A.aL(0,w,0,1/0)
u=b1.O===C.O&&!0
t=b1.av===C.oI&&!0
break
case 1:w=b3.d
v=new A.aL(0,1/0,0,w)
u=b1.av===C.oI&&!0
t=b1.O===C.O&&!0
break
default:v=null
w=0
u=!1
t=!1}s=b1.a7
r=b1.V
q=A.a([],y.q)
for(p=y.E,o=0,n=0,m=0,l=0,k=0;x!=null;){x.cw(v,!0)
j=x.id
i=b1.O9(j==null?A.U(A.a7(b2+A.I(x).j(0)+"#"+A.bG(x))):j)
j=x.id
h=b1.O8(j==null?A.U(A.a7(b2+A.I(x).j(0)+"#"+A.bG(x))):j)
if(k>0&&m+s+i>w){o=Math.max(o,m)
n+=l
if(q.length!==0)n+=r
q.push(new B.WG(m,l,k))
m=0
l=0
k=0}m+=i
if(k>0)m+=s
l=Math.max(l,h);++k
j=x.b
j.toString
p.a(j)
j.e=q.length
x=j.ap$}if(k>0){o=Math.max(o,m)
n+=l
if(q.length!==0)n+=r
q.push(new B.WG(m,l,k))}g=q.length
switch(b1.C.a){case 0:b1.id=b3.b7(new A.Z(o,n))
f=b1.gt(b1).a
e=b1.gt(b1).b
break
case 1:b1.id=b3.b7(new A.Z(n,o))
f=b1.gt(b1).b
e=b1.gt(b1).a
break
default:f=0
e=0}b1.cL=f<o||e<n
d=Math.max(0,e-n)
switch(b1.T.a){case 0:a0=0
a1=0
break
case 1:a0=d
a1=0
break
case 2:a0=d/2
a1=0
break
case 3:a1=g>1?d/(g-1):0
a0=0
break
case 4:a1=d/g
a0=a1/2
break
case 5:a1=d/(g+1)
a0=a1
break
default:a0=0
a1=0}a1+=r
a2=t?e-a0:a0
x=b1.a9$
for(a3=0;a3<g;++a3){a4=q[a3]
l=a4.b
k=a4.c
a5=Math.max(0,f-a4.a)
switch(b1.U.a){case 0:a6=0
a7=0
break
case 1:a6=a5
a7=0
break
case 2:a6=a5/2
a7=0
break
case 3:a7=k>1?a5/(k-1):0
a6=0
break
case 4:a7=a5/k
a6=a7/2
break
case 5:a7=a5/(k+1)
a6=a7
break
default:a6=0
a7=0}a7+=s
a8=u?f-a6:a6
if(t)a2-=l
for(;x!=null;){j=x.b
j.toString
p.a(j)
if(j.e!==a3)break
a9=x.id
i=b1.O9(a9==null?A.U(A.a7(b2+A.I(x).j(0)+"#"+A.bG(x))):a9)
a9=x.id
b0=b1.atz(t,l,b1.O8(a9==null?A.U(A.a7(b2+A.I(x).j(0)+"#"+A.bG(x))):a9))
if(u)a8-=i
j.a=b1.atT(a8,a2+b0)
a8=u?a8-a7:a8+(i+a7)
x=j.ap$}a2=t?a2-a1:a2+(l+a1)}},
dH(d,e){return this.r8(d,e)},
aT(d,e){var x,w=this,v=w.cL&&w.bM!==C.l,u=w.ca
if(v){v=w.cx
v===$&&A.b()
x=w.gt(w)
u.saV(0,d.nl(v,e,new A.G(0,0,0+x.a,0+x.b),w.ga8i(),w.bM,u.a))}else{u.saV(0,null)
w.pn(d,e)}},
n(){this.ca.saV(0,null)
this.ic()}}
B.anL.prototype={
aH(d){var x,w,v
this.ez(d)
x=this.a9$
for(w=y.E;x!=null;){x.aH(d)
v=x.b
v.toString
x=w.a(v).ap$}},
aB(d){var x,w,v
this.ek(0)
x=this.a9$
for(w=y.E;x!=null;){x.aB(0)
v=x.b
v.toString
x=w.a(v).ap$}}}
B.anM.prototype={}
B.agY.prototype={
aR(d){var x=A.dF(d)
x=new B.QL(C.aa,D.kA,0,D.kA,0,D.KE,x,C.eo,C.l,A.aA(y.I),0,null,null,A.aA(y.v))
x.aS()
x.K(0,null)
return x},
aZ(d,e){var x
e.sSp(0,C.aa)
e.shJ(D.kA)
e.saiA(0,0)
e.saSI(D.kA)
e.saSJ(0)
e.sS_(D.KE)
x=A.dF(d)
if(e.O!=x){e.O=x
e.ab()}if(e.av!==C.eo){e.av=C.eo
e.ab()}if(C.l!==e.bM){e.bM=C.l
e.aM()
e.c3()}}}
B.L2.prototype={
G(d){return G.eb(null,null,new B.awx(),y.c,y.i)}}
var z=a.updateTypes(["R(R)"])
B.awx.prototype={
$2(d,e){var x,w,v,u,t,s,r,q,p,o,n,m=null,l="language_iso",k=A.a([],y.b)
if(e instanceof A.iQ)k=e.c
x=y.p
w=A.a([new A.F(20,m,m,m)],x)
if(k.length!==0){v=A.a_("categories")
u=y.S
t=y.a
s=t.a(A.r(d).c.h(0,A.S(u)))
s.toString
r=A.a_(l)==="ar"?2:1
r=A.ar(v,m,m,m,m,m,m,m,A.an(m,m,s.b,m,m,m,m,m,m,m,m,17,m,m,C.p,m,r,!0,m,m,m,m,m,m,m,m),m,m,m)
u=t.a(A.r(d).c.h(0,A.S(u)))
u.toString
w.push(new A.bj(E.dL,A.ck(!1,m,!0,A.ay(A.a([r,A.cp(F.dV,u.Q,m,17)],x),C.f,C.j,C.bc,m),m,!0,m,m,m,m,m,m,m,m,m,m,new B.awv(d),m,m,m,m,m,m,m),m))}for(v=k.length,u=y.S,t=y.a,q=0;q<k.length;k.length===v||(0,A.t)(k),++q){p=k[q]
s=p.a
s===$&&A.b()
r=C.b.gI(k).a
r===$&&A.b()
s=s===r?m:new B.aww(d,p)
r=J.a9($.nA,l)
r=(r==null?l:r)==="ar"?p.d:p.c
if(r==null)r=""
o=p.a
n=C.b.gI(k).a
n===$&&A.b()
if(o===n){o=t.a(A.r(d).c.h(0,A.S(u)))
o.toString
o=o.r}else{o=t.a(A.r(d).c.h(0,A.S(u)))
o.toString
o=o.b}n=J.a9($.nA,l)
n=(n==null?l:n)==="ar"?2:1
r=A.a([new A.lt(r,m,new A.V(!0,o,m,m,m,m,17,C.p,m,m,m,m,n,m,m,m,m,m,m,m,m,m,m,m,m,m),m,m,m,m,m,m,m,m,m,m)],x)
o=p.a
n=C.b.gI(k).a
n===$&&A.b()
if(o!==n){o=t.a(A.r(d).c.h(0,A.S(u)))
o.toString
r.push(new A.oj(F.dV,17,o.Q,m,m))}w.push(new A.bj(E.dL,A.ck(!1,m,!0,A.ay(r,C.f,C.j,C.bc,m),m,!0,m,m,m,m,m,m,m,m,m,m,s,m,m,m,m,m,m,m),m))}return new A.ht(H.bR,m,m,B.bkh(w),m)},
$S:576}
B.awv.prototype={
$0(){var x=y.X
A.bD(this.a,!1).lF("categories",x,x)},
$S:0}
B.aww.prototype={
$0(){var x,w=A.bD(this.a,!1),v=this.b.a
v===$&&A.b()
x=y.X
w.lF("categories/"+v,x,x)},
$S:0};(function installTearOffs(){var x=a._instance_1u
var w
x(w=B.QL.prototype,"gbR","bI",0)
x(w,"gc8","bu",0)
x(w,"gcn","bB",0)
x(w,"gcR","bF",0)})();(function inheritance(){var x=a.mixinHard,w=a.mixin,v=a.inheritMany,u=a.inherit
v(A.pf,[B.aUG,B.aUH])
u(B.WG,A.C)
u(B.qY,A.v3)
u(B.anL,A.B)
u(B.anM,B.anL)
u(B.QL,B.anM)
u(B.agY,A.eY)
u(B.L2,A.ac)
u(B.awx,A.f9)
v(A.fx,[B.awv,B.aww])
x(B.anL,A.aD)
w(B.anM,A.dh)})()
A.eA(b.typeUniverse,JSON.parse('{"qY":{"fo":[],"eU":["B"],"dt":[]},"QL":{"dh":["B","qY"],"B":[],"aD":["B","qY"],"x":[],"az":[],"aD.1":"qY","dh.1":"qY","aD.0":"B"},"agY":{"eY":[],"aF":[],"e":[]},"L2":{"ac":[],"e":[]}}'))
var y=(function rtii(){var x=A.J
return{S:x("cB"),k:x("aL"),I:x("pF"),v:x("et"),c:x("kb"),i:x("dM"),b:x("j<pD>"),p:x("j<e>"),q:x("j<WG>"),E:x("qY"),a:x("cB?"),X:x("C?")}})();(function constants(){D.kA=new B.aUG(0,"start")
D.KE=new B.aUH(0,"start")})()};
((a,b)=>{a[b]=a.current
a.eventLog.push({p:"main.dart.js_20",e:"endPart",h:b})})($__dart_deferred_initializers__,"5djwJxtyvaueaKslV37FtMlMroM=");