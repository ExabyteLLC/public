((a,b,c)=>{a[b]=a[b]||{}
a[b][c]=a[b][c]||[]
a[b][c].push({p:"main.dart.js_21",e:"beginPart"})})(self,"$__dart_deferred_initializers__","eventLog")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B={
btw(){return new B.a_G(null)},
a_G:function a_G(d){this.a=d}},E,A,D,C,F
B=a.updateHolder(c[5],B)
E=c[31]
A=c[0]
D=c[33]
C=c[16]
F=c[32]
B.a_G.prototype={
G(d){var y=null
if($.bF>768)return new E.jO(new A.bj(D.lU,new C.yd(!1,y),y),y,y,y,!1,y)
else return F.qE(y,y,y,y,new A.bj(D.lU,new C.yd(!1,y),y),-1,A.a_("brands"),y,!1)}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(B.a_G,A.ac)})()
A.eA(b.typeUniverse,JSON.parse('{"a_G":{"ac":[],"e":[]}}'))};
((a,b)=>{a[b]=a.current
a.eventLog.push({p:"main.dart.js_21",e:"endPart",h:b})})($__dart_deferred_initializers__,"f7MfZFLNtx8jDYwLxaUhuE4UTQE=");