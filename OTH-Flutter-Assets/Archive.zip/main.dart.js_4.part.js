((a,b,c)=>{a[b]=a[b]||{}
a[b][c]=a[b][c]||[]
a[b][c].push({p:"main.dart.js_4",e:"beginPart"})})(self,"$__dart_deferred_initializers__","eventLog")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A={wM:function wM(d){this.a=d}},B
A=a.updateHolder(c[23],A)
B=c[0]
A.wM.prototype={}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(A.wM,B.kc)})()
B.eA(b.typeUniverse,JSON.parse('{"wM":{"kc":[]}}'))};
((a,b)=>{a[b]=a.current
a.eventLog.push({p:"main.dart.js_4",e:"endPart",h:b})})($__dart_deferred_initializers__,"sTqAIaNUPNAW8nxBSe+y+sxsORY=");