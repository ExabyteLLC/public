((a,b,c)=>{a[b]=a[b]||{}
a[b][c]=a[b][c]||[]
a[b][c].push({p:"main.dart.js_3",e:"beginPart"})})(self,"$__dart_deferred_initializers__","eventLog")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A={j2:function j2(){}},B
A=a.updateHolder(c[28],A)
B=c[0]
A.j2.prototype={
us(){}}
var z=a.updateTypes([]);(function aliases(){var y=A.j2.prototype
y.zP=y.us})();(function inheritance(){var y=a.inherit
y(A.j2,B.C)})()};
((a,b)=>{a[b]=a.current
a.eventLog.push({p:"main.dart.js_3",e:"endPart",h:b})})($__dart_deferred_initializers__,"gztGkdjOBRZ6AHL/02yqYD4TNDI=");