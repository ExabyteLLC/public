((a,b,c)=>{a[b]=a[b]||{}
a[b][c]=a[b][c]||[]
a[b][c].push({p:"main.dart.js_26",e:"beginPart"})})(self,"$__dart_deferred_initializers__","eventLog")
$__dart_deferred_initializers__.current=function(a,b,c,$){var C={a4R:function a4R(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g}},B,A
C=a.updateHolder(c[25],C)
B=c[0]
A=c[2]
C.a4R.prototype={
aSU(){var y=this,x=y.d,w=(1-Math.abs(2*x-1))*y.c,v=y.b
return B.bDU(y.a,v,w,w*(1-Math.abs(A.d.au(v/60,2)-1)),x-w/2)},
l(d,e){var y=this
if(e==null)return!1
if(y===e)return!0
return e instanceof C.a4R&&e.a===y.a&&e.b===y.b&&e.c===y.c&&e.d===y.d},
gv(d){var y=this
return B.a1(y.a,y.b,y.c,y.d,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a)},
j(d){var y=this
return"HSLColor("+B.f(y.a)+", "+B.f(y.b)+", "+B.f(y.c)+", "+B.f(y.d)+")"}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(C.a4R,B.C)})()};
((a,b)=>{a[b]=a.current
a.eventLog.push({p:"main.dart.js_26",e:"endPart",h:b})})($__dart_deferred_initializers__,"XTDfULw7O4nkMCUSwzsCHNVr9Ro=");