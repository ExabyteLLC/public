((a,b,c)=>{a[b]=a[b]||{}
a[b][c]=a[b][c]||[]
a[b][c].push({p:"main.dart.js_7",e:"beginPart"})})(self,"$__dart_deferred_initializers__","eventLog")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,A
B=c[45]
A=c[0]
var z=a.updateTypes([]);(function constants(){B.lT=new A.d8(10,0,0,0)
B.dV=new A.cY(57500,"MaterialIcons",null,!0)})()};
((a,b)=>{a[b]=a.current
a.eventLog.push({p:"main.dart.js_7",e:"endPart",h:b})})($__dart_deferred_initializers__,"bl8Wikq+JYIk9eile9yvheAr5JA=");