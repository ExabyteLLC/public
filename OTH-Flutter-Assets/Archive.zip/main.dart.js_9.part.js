((a,b,c)=>{a[b]=a[b]||{}
a[b][c]=a[b][c]||[]
a[b][c].push({p:"main.dart.js_9",e:"beginPart"})})(self,"$__dart_deferred_initializers__","eventLog")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A={aPO:function aPO(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},aPP:function aPP(){},aPQ:function aPQ(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i},aPN:function aPN(){},H6:function H6(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.e=g},H7:function H7(d,e,f){var _=this
_.b=_.w=null
_.c=!1
_.xY$=d
_.ds$=e
_.ap$=f
_.a=null},abg:function abg(d,e,f,g,h,i,j){var _=this
_.e3=d
_.ah=e
_.bb=f
_.bk=$
_.b5=!0
_.er$=g
_.a9$=h
_.dM$=i
_.fx=null
_.a=!1
_.b=null
_.c=0
_.e=_.d=null
_.r=_.f=!1
_.w=null
_.x=!1
_.y=null
_.z=!0
_.Q=null
_.as=!1
_.at=null
_.ax=!1
_.ay=$
_.ch=j
_.CW=!1
_.cx=$
_.cy=!0
_.db=!1
_.dx=null
_.dy=!0
_.fr=null},
aEc(d,e,f,g,h){var x=null
return new A.a4P(d,new D.RR(e,f,!0,!0,!0,x),x,C.J,!1,x,x,g,!0,x,f,C.K,E.nQ,x,C.T,x)},
a4P:function a4P(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s){var _=this
_.p3=d
_.p4=e
_.cx=f
_.c=g
_.d=h
_.e=i
_.f=j
_.r=k
_.x=l
_.Q=m
_.as=n
_.at=o
_.ax=p
_.ay=q
_.ch=r
_.a=s},
acO:function acO(d,e,f){this.f=d
this.d=e
this.a=f}},C,B,D,E
A=a.updateHolder(c[29],A)
C=c[2]
B=c[0]
D=c[32]
E=c[35]
A.aPO.prototype={
ag4(d){var x=this.c
return d.Bg(this.d,x,x)},
j(d){var x=this
return"SliverGridGeometry("+C.b.cl(B.a(["scrollOffset: "+B.f(x.a),"crossAxisOffset: "+B.f(x.b),"mainAxisExtent: "+B.f(x.c),"crossAxisExtent: "+B.f(x.d)],y.x),", ")+")"}}
A.aPP.prototype={}
A.aPQ.prototype={
agl(d){var x=this.b
if(x>0)return Math.max(0,this.a*C.d.dr(d/x)-1)
return 0},
atU(d){var x,w,v=this
if(v.f){x=v.c
w=v.e
return v.a*x-d-w-(x-w)}return d},
Lp(d){var x=this,w=x.a,v=C.e.au(d,w)
return new A.aPO(C.e.jM(d,w)*x.b,x.atU(v*x.c),x.d,x.e)},
a7j(d){var x
if(d===0)return 0
x=this.b
return x*(C.e.jM(d-1,this.a)+1)-(x-this.d)}}
A.aPN.prototype={}
A.H6.prototype={
W1(d){var x=this,w=x.c,v=x.a,u=Math.max(0,d.w-w*(v-1))/v,t=x.e
if(t==null)t=u/1
return new A.aPQ(v,t+x.b,u+w,t,u,B.asA(d.x))}}
A.H7.prototype={
j(d){return"crossAxisOffset="+B.f(this.w)+"; "+this.alV(0)}}
A.abg.prototype={
fB(d){if(!(d.b instanceof A.H7))d.b=new A.H7(!1,null,null)},
sagT(d){var x,w=this
if(w.e3===d)return
if(B.I(d)===B.I(w.e3)){x=w.e3
if(x.a===d.a)if(x.b===d.b)if(x.c===d.c)x=x.e!=d.e
else x=!0
else x=!0
else x=!0}else x=!0
if(x)w.ab()
w.e3=d},
xj(d){var x=d.b
x.toString
x=y.t.a(x).w
x.toString
return x},
bP(){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5=this,a6=null,a7=y.z.a(B.x.prototype.gad.call(a5)),a8=a5.ah
a8.R8=!1
x=a7.d
w=x+a7.z
v=w+a7.Q
u=a5.e3.W1(a7)
t=u.b
s=t>1e-10?u.a*C.d.jM(w,t):0
r=isFinite(v)?u.agl(v):a6
t=a5.a9$
if(t!=null){t=t.b
t.toString
q=y.c
t=q.a(t).b
t.toString
p=a5.dM$
p.toString
p=p.b
p.toString
p=q.a(p).b
p.toString
o=C.e.cO(s-t,0,a5.er$)
a5.uk(o,r==null?0:C.e.cO(p-r,0,a5.er$))}else a5.uk(0,0)
n=u.Lp(s)
if(a5.a9$==null)if(!a5.QE(s,n.a)){m=u.a7j(a8.gBw())
a5.fx=D.nn(a6,!1,a6,a6,m,0,0,m,a6)
a8.uq()
return}l=n.a
k=l+n.c
t=a5.a9$
t.toString
t=t.b
t.toString
q=y.c
t=q.a(t).b
t.toString
j=t-1
t=y.t
i=a6
for(;j>=s;--j){h=u.Lp(j)
p=h.c
g=a5.aaO(a7.Bg(h.d,p,p))
f=g.b
f.toString
t.a(f)
e=h.a
f.a=e
f.w=h.b
if(i==null)i=g
k=Math.max(k,e+p)}if(i==null){p=a5.a9$
p.toString
p.i3(n.ag4(a7))
i=a5.a9$
p=i.b
p.toString
t.a(p)
p.a=l
p.w=n.b}p=i.b
p.toString
p=q.a(p).b
p.toString
j=p+1
p=B.n(a5).i("aD.1")
f=r!=null
while(!0){if(!(!f||j<=r))break
h=u.Lp(j)
e=h.c
d=a7.Bg(h.d,e,e)
a0=i.b
a0.toString
g=p.a(a0).ap$
if(g!=null){a0=g.b
a0.toString
a0=q.a(a0).b
a0.toString
a0=a0!==j}else a0=!0
if(a0){g=a5.aaM(d,i)
if(g==null)break}else g.i3(d)
a0=g.b
a0.toString
t.a(a0)
a1=h.a
a0.a=a1
a0.w=h.b
k=Math.max(k,a1+e);++j
i=g}t=a5.dM$
t.toString
t=t.b
t.toString
t=q.a(t).b
t.toString
a2=a8.SL(a7,s,t,l,k)
a3=a5.m2(a7,Math.min(x,l),k)
a4=a5.ui(a7,l,k)
a5.fx=D.nn(a4,a2>a3||x>0||a7.f!==0,a6,a6,a2,a3,0,a2,a6)
if(a2===k)a8.R8=!0
a8.uq()}}
A.a4P.prototype={
a6B(d){return new A.acO(this.p3,this.p4,null)}}
A.acO.prototype={
aR(d){var x=new A.abg(this.f,y.v.a(d),B.E(y.e,y.g),0,null,null,B.aA(y.d))
x.aS()
return x},
aZ(d,e){e.sagT(this.f)},
SK(d,e,f,g,h){var x,w
this.alW(d,e,f,g,h)
x=this.f.W1(d)
w=this.d.gxN()
w.toString
w=x.a7j(w)
return w}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inheritMany,w=a.inherit
x(B.C,[A.aPO,A.aPP,A.aPN])
w(A.aPQ,A.aPP)
w(A.H6,A.aPN)
w(A.H7,D.i6)
w(A.abg,D.qC)
w(A.a4P,D.KQ)
w(A.acO,D.oR)})()
B.eA(b.typeUniverse,JSON.parse('{"H7":{"i6":[],"tM":[],"eU":["B"],"on":[],"dt":[]},"abg":{"qC":[],"dZ":[],"aD":["B","i6"],"x":[],"az":[],"aD.1":"i6","aD.0":"B"},"a4P":{"ac":[],"e":[]},"acO":{"oR":[],"aF":[],"e":[]}}'))
var y={d:B.J("et"),x:B.J("j<h>"),g:B.J("B"),z:B.J("qJ"),t:B.J("H7"),v:B.J("wV"),c:B.J("i6"),e:B.J("o")}};
((a,b)=>{a[b]=a.current
a.eventLog.push({p:"main.dart.js_9",e:"endPart",h:b})})($__dart_deferred_initializers__,"s8zCalijF8GwpAAqQnNkI3eoBVw=");