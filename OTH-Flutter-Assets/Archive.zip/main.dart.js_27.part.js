((a,b,c)=>{a[b]=a[b]||{}
a[b][c]=a[b][c]||[]
a[b][c].push({p:"main.dart.js_27",e:"beginPart"})})(self,"$__dart_deferred_initializers__","eventLog")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B={KI:function KI(d){this.a=d},av9:function av9(){},
bvC(){return new B.a43(null)},
a43:function a43(d){this.a=d}},D,F,A,C,E
B=a.updateHolder(c[8],B)
D=c[32]
F=c[31]
A=c[0]
C=c[2]
E=c[27]
B.KI.prototype={
G(d){return D.eb(null,null,new B.av9(),y.m,y.f)}}
B.a43.prototype={
G(d){var x=null
if($.bF>768)return new F.jO(new B.KI(x),x,x,x,!1,x)
else return D.qE(x,x,x,x,new B.KI(x),2,A.a_("favourite"),x,!1)}}
var z=a.updateTypes([])
B.av9.prototype={
$2(d,e){var x=null,w=y.e,v=A.a([],w)
if($.bF>768)v.push(new A.F(x,20,x,x))
if($.bF>768)v.push(A.ay(A.a([A.ar(A.a_("favourite"),x,x,x,x,x,x,x,A.an(x,x,x,x,x,x,x,x,x,x,x,25,x,x,C.p,x,x,!0,x,x,x,x,x,x,x,x),x,x,x)],w),C.f,C.aB,C.i,x))
if($.bF>768)v.push(new A.F(x,20,x,x))
v.push(new E.ws(e.a,x,x))
v.push(new A.F(x,20,x,x))
return A.bI(v,C.f,C.j,C.i,x)},
$S:587};(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.ac,[B.KI,B.a43])
w(B.av9,A.f9)})()
A.eA(b.typeUniverse,JSON.parse('{"KI":{"ac":[],"e":[]},"a43":{"ac":[],"e":[]}}'))
var y={m:A.J("od"),f:A.J("eI"),e:A.J("j<e>")}};
((a,b)=>{a[b]=a.current
a.eventLog.push({p:"main.dart.js_27",e:"endPart",h:b})})($__dart_deferred_initializers__,"+7KV3X2abYuzQKYmi4KNopX3NnA=");